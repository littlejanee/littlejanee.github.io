To view a full list of participants' designs:
- Make sure the whole 'user study designs' folder is downloaded to your laptop.
- Open 'user-design-list.html' with your browser. 